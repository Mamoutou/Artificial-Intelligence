
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class CSPZebraProblem extends CSP {
    private static Set<Object> varColor = new HashSet<Object>(Arrays.asList(new String[] {"blue", "green", "ivory", "red", "yellow"}));
    private static Set<Object> varDrink = new HashSet<Object>(Arrays.asList(new String[] {"coffee", "milk", "orange-juice", "tea", "water"}));
    private static Set<Object> varNationality = new HashSet<Object>(Arrays.asList(new String[] {"englishman", "japanese", "norwegian", "spaniard", "ukrainian"}));
    private static Set<Object> varPet = new HashSet<Object>(Arrays.asList(new String[] {"dog", "fox", "horse", "snails", "zebra"}));
    private static Set<Object> varCigarette = new HashSet<Object>(Arrays.asList(new String[] {"chesterfield", "kools", "lucky-strike", "old-gold", "parliament"}));

    
    public static void main(String[] args) {
        
        CSPZebraProblem csp = new CSPZebraProblem();
        Integer[] domain = {1,2,3,4,5};

        for (Object X : varColor) {
            csp.addDomain(X, domain);
        }

        for (Object X : varDrink) {
            csp.addDomain(X, domain);
        }

        for (Object X : varNationality) {
            csp.addDomain(X, domain);
        }

        for (Object X : varPet) {
            csp.addDomain(X, domain);
        }

        for (Object X : varCigarette) {
            csp.addDomain(X, domain);
        }

        // Unary constraints
        csp.addDomain("milk", new Integer[]{3});
        csp.addDomain("norwegian", new Integer[]{1});

        // Binary constraints: add constraint arcs
        Object[][] binaryConditions = {
                {"englishman", "red"},
                {"spaniard", "dog"},
                {"coffee", "green"},
                {"ukrainian", "tea"},
                {"old-gold", "snails"},
                {"kools", "yellow"},
                {"lucky-strike", "orange-juice"},
                {"japanese", "parliament"}
        };

        for (Object[] pair : binaryConditions) {
            csp.addBidirectionalArc(pair[0], pair[1]);
        }

        // Uniqueness constraints
        Object[] variables = {
                varColor,
                varDrink,
                varNationality,
                varPet,
                varCigarette
        };

        for (Object var : variables) {
             @SuppressWarnings("unchecked") Set<Object> set = (Set<Object>)var;
            for (Object X : set) {
                for (Object Y : set) {
                    if (!X.equals(Y)) {
                        csp.addBidirectionalArc(X, Y);
                    }
                }
            }
        }

        Search search = new Search(csp);
        System.out.println(search.BacktrackingSearch());
    }
    
    
    public boolean isGood(Object X, Object Y, Object x, Object y) {
       
        if (!C.containsKey(X)) {
            return true;
        }

        // Rules 1, 2, 3, 4, 6, 7, 12, 13
        Object[][] conditions = {
                {"englishman", "red"},
                {"spaniard", "dog"},
                {"coffee", "green"},
                {"ukrainian", "tea"},
                {"old-gold", "snails"},
                {"kools", "yellow"},
                {"lucky-strike", "orange-juice"},
                {"japanese", "parliament"}
        };

        for (Object[] pair : conditions) {
            if (X.equals(pair[0]) && Y.equals(pair[1]) && !x.equals(y)) {
                return false;
            }

        }

        // Rules 8, 9 (works)
        Object[][] conditions2 = {
                {"milk", new Integer(3)},
                {"norwegian", new Integer(1)}
        };

        for (Object[] pair : conditions2) {
            if ((X.equals(pair[0]) && !x.equals(pair[1])) || (Y.equals(pair[0]) && !y.equals(pair[1]))) {
                return false;
            }
        }

        // Rule 5 (works)
        if ((X.equals("green") && Y.equals("ivory") && !((Integer)x - (Integer)y == 1)) ||
                (X.equals("ivory") && Y.equals("green") && !((Integer)x - (Integer)y == -1))) {
            return false;
        }

        // Rules 10, 11, 14 (works)
        Object[][] conditions3 = {
                {"chesterfield", "fox"},
                {"norwegian", "blue"},
                {"kools", "horse"}
        };

        for (Object[] pair : conditions3) {
            if ((X.equals(pair[0]) && Y.equals(pair[1]) && !(Math.abs((Integer)x - (Integer)y) == 1))) {
                return false;
            }
        }

        Object[] variables = {
                varColor,
                varDrink,
                varNationality,
                varPet,
                varCigarette
        };
        /* @SuppressWarnings("unchecked")*/ 
        for (Object var : variables) {
           @SuppressWarnings("unchecked") Set<Object> set = (Set<Object>)var;
            if (set.contains(X) && set.contains(Y) && !X.equals(Y) && x.equals(y)) {
                return false;
            }
        }

        if (!C.get(X).contains(Y)) {
            return true;
        }

        return true;
    }

 
}
