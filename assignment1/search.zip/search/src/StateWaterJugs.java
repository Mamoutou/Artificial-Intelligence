
public class StateWaterJugs {
	   int[] jugs = new int[3];
		
		public StateWaterJugs() { 
	    	this.jugs = new int[3];
			this.jugs[0] = 0;
			this.jugs[1] = 0;
			this.jugs[2] = 0;
	    }

}
